<?php

return [
  'settings' => [
    'displayErrorDetails' => true, // set to false in production
  ],
];
